import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class watch extends PApplet {

PImage anzu,conoha1,conoha2,pronama,query,unity,cloudia;
int pic = 0,cF = 0;

public void setup(){
  size(350,350);
  frameRate(60);
  smooth();
  anzu = loadImage("anzu.png");
  conoha1 = loadImage("conoha_1.png");
  conoha2 = loadImage("conoha_2.png");
  pronama = loadImage("pronama.JPG");
  query = loadImage("query.png");
  unity = loadImage("unity.png");
  cloudia = loadImage("cloudia.png");
}

public void draw(){
  background(255);
  tint(255,120);
  switch(pic){
    case 0:
      image(anzu,0,0,width,height);
      break;
    case 1:
      image(unity,0,0,width,height);
      break;
    case 2:
      image(pronama,0,0,width,height);
      break;
    case 3:
      image(query,0,0,width,height);
      break;
    case 4:
      if(second() % 2 == 0)
        image(conoha1,0,0,width,height);
      else
        image(conoha2,0,0,width,height);
      break;
    case 5:
      image(cloudia,0,0,width,height);
      break;
  }
  noTint();
  fill(0);
  String time = hour() + " : " + minute() + " : " + second();
  text(time,width / 2 - textWidth(time) / 2 + textWidth(" ") * 2,height - 15);
  // button("\u5207\u308a\u66ff\u3048",width - 75,height - 35,70,30);
  ellipseMode(RADIUS);
  int watchSize = 0;
  if(width <= height){
    watchSize = width / 2 - 25;
  }else{
    watchSize = height / 2 - 25;
  }
  
  translate(width / 2,height / 2 - 15);
  noFill();
  strokeWeight(1);
  ellipse(0,0,watchSize,watchSize);
  strokeWeight(10);
  point(0,0);
  // \u79d2\u91dd
  pushMatrix();
  rotate(radians(second() * (360 / 60)));
  strokeWeight(2);
  line(0,0,0,-140);
  popMatrix();
  // \u5206\u91dd
  pushMatrix();
  rotate(radians((minute() + second() / 60.0f) * (360 / 60.0f)));
  strokeWeight(3);
  line(0,0,0,-100);
  popMatrix();
  // \u6642\u91dd
  pushMatrix();
  rotate(radians((hour() + minute() / 60.0f) * (360 / 12.0f)));
  strokeWeight(6);
  line(0,0,0,-70);
  popMatrix();
}

public void mouseReleased(){
  if(pic != 5){
    pic += 1;
  }else{
    pic = 0;
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "watch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
